# XXXTENTACION — The Chaos Archive

Site estático em HTML/CSS/JavaScript, sem dependências ou build.

## Como visualizar
Abra `index.html` no navegador.

## Como publicar gratuitamente
1. Crie uma conta em https://github.com/ e um repositório.
2. Envie o arquivo `index.html` para o repositório.
3. Em Settings → Pages, escolha Deploy from a branch, selecione `main` e `/root`.
4. O GitHub Pages fornecerá um endereço público.

Também é possível publicar a pasta em https://www.netlify.com/ ou https://vercel.com/.

## Observações
- O ranking contém valores aproximados/ilustrativos, não dados ao vivo nem uma API oficial do Spotify.
- Algumas imagens são carregadas de servidores externos. Verifique créditos, direitos de uso e disponibilidade antes de divulgação pública.
- O projeto é independente e não é afiliado à família, gravadora ou equipe de XXXTENTACION.
